package id.memotugas.app

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Task(val id: Long, val course: String, val title: String, val description: String,
                val deadline: Long, val instruction: String?, val result: String?, val status: String)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("memo", MODE_PRIVATE) }
    private val tasks = mutableListOf<Task>()
    private lateinit var list: LinearLayout
    private var filter = "Semua"
    private var due = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 7) }
    private var instruction: String? = null
    private var result: String? = null

    private val pickInstruction = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { keep(it); instruction = it.toString(); Toast.makeText(this, "File instruksi dipilih", Toast.LENGTH_SHORT).show() }
    }
    private val pickResult = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { keep(it); result = it.toString(); Toast.makeText(this, "Hasil tugas dipilih", Toast.LENGTH_SHORT).show() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 20, 18, 12); setBackgroundColor(0xfff5f6fa.toInt()) }
        root.addView(label("Memo Tugas 3.0\\nCatat • Pantau • Selesaikan", 24f, 0xff192746.toInt()))
        root.addView(button("+ Tambah tugas") { form(null) })
        val filters = LinearLayout(this)
        listOf("Semua", "Belum", "Selesai").forEach { f -> filters.addView(button(f) { filter = f; render() }, LinearLayout.LayoutParams(0, 48, 1f)) }
        root.addView(filters)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        render()
    }

    private fun render() {
        list.removeAllViews()
        val done = tasks.count { it.status == "Selesai" }
        list.addView(label("${tasks.size} tugas • ${tasks.size-done} belum selesai • $done selesai", 14f))
        val shown = tasks.filter { when(filter) { "Belum" -> it.status != "Selesai"; "Selesai" -> it.status == "Selesai"; else -> true } }.sortedBy { it.deadline }
        if (shown.isEmpty()) list.addView(label("Belum ada tugas. Tekan Tambah tugas untuk memulai.", 15f))
        shown.forEach { t ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 10, 12, 10); setBackgroundColor(Color.WHITE); elevation = 3f }
            card.addView(label(t.course, 13f, Color.GRAY))
            card.addView(label(t.title, 19f, 0xff192746.toInt()))
            val left = daysLeft(t.deadline)
            val dueText = when { t.status == "Selesai" -> "SELESAI"; left < 0 -> "TERLAMBAT ${-left} HARI"; left == 0 -> "DEADLINE HARI INI"; else -> "H-$left" }
            val dueColor = when { t.status == "Selesai" -> 0xff168855.toInt(); left <= 1 -> 0xffc9412d.toInt(); left <= 3 -> 0xffc18719.toInt(); else -> 0xff287d55.toInt() }
            card.addView(label("$dueText • ${date(t.deadline)}", 16f, dueColor))
            card.addView(label("Status: ${t.status}", 13f))
            val row = LinearLayout(this)
            row.addView(button("Detail") { detail(t) }, LinearLayout.LayoutParams(0, 44, 1f))
            row.addView(button("Edit") { form(t) }, LinearLayout.LayoutParams(0, 44, 1f))
            row.addView(button("Hapus") { android.app.AlertDialog.Builder(this).setMessage("Hapus tugas ini?").setNegativeButton("Batal", null).setPositiveButton("Hapus") { _, _ -> tasks.removeAll { it.id == t.id }; save(); render() }.show() }, LinearLayout.LayoutParams(0, 44, 1f))
            card.addView(row)
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8, 0, 8) })
        }
    }

    private fun form(old: Task?) {
        instruction = old?.instruction
        result = old?.result
        due = Calendar.getInstance().apply { timeInMillis = old?.deadline ?: Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 7) }.timeInMillis }
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 8, 18, 8) }
        val course = field("Mata kuliah", old?.course.orEmpty())
        val title = field("Nama tugas", old?.title.orEmpty())
        val desc = field("Deskripsi (opsional)", old?.description.orEmpty(), false)
        panel.addView(course); panel.addView(title); panel.addView(desc)
        val dateLabel = label("Deadline: ${date(due.timeInMillis)}", 15f)
        panel.addView(dateLabel)
        panel.addView(button("Pilih deadline") {
            DatePickerDialog(this, { _, y, m, d -> due.set(y, m, d, 12, 0, 0); dateLabel.text = "Deadline: ${date(due.timeInMillis)}" },
                due.get(Calendar.YEAR), due.get(Calendar.MONTH), due.get(Calendar.DAY_OF_MONTH)).show()
        })
        panel.addView(button("Pilih file instruksi (opsional)") { pickInstruction.launch(arrayOf("*/*")) })
        panel.addView(button("Pilih hasil tugas (opsional)") { pickResult.launch(arrayOf("*/*")) })
        val status = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Belum dikerjakan", "Proses", "Selesai"))
            setSelection(listOf("Belum dikerjakan", "Proses", "Selesai").indexOf(old?.status ?: "Belum dikerjakan").coerceAtLeast(0))
        }
        panel.addView(label("Status", 14f)); panel.addView(status)
        val dialog = android.app.AlertDialog.Builder(this).setTitle(if (old == null) "Tambah tugas" else "Edit tugas")
            .setView(ScrollView(this).apply { addView(panel) }).setNegativeButton("Batal", null).setPositiveButton("Simpan", null).create()
        dialog.setOnShowListener {
            dialog.getButton(-1).setOnClickListener {
                if (course.text.isBlank() || title.text.isBlank()) { Toast.makeText(this, "Mata kuliah dan nama tugas wajib diisi", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                val item = Task(old?.id ?: System.currentTimeMillis(), course.text.toString().trim(), title.text.toString().trim(),
                    desc.text.toString().trim(), due.timeInMillis, instruction, result, status.selectedItem.toString())
                if (old == null) tasks.add(item) else { val i = tasks.indexOfFirst { it.id == old.id }; if (i >= 0) tasks[i] = item }
                save(); render(); dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun detail(t: Task) {
        val msg = "Mata kuliah: ${t.course}\\nTugas: ${t.title}\\nDeskripsi: ${t.description.ifBlank { "—" }}\\nDeadline: ${date(t.deadline)}\\nStatus: ${t.status}\\nInstruksi: ${t.instruction?.let { name(Uri.parse(it)) } ?: "Tidak ada"}\\nHasil: ${t.result?.let { name(Uri.parse(it)) } ?: "Belum ada"}"
        val b = android.app.AlertDialog.Builder(this).setTitle("Detail tugas").setMessage(msg).setPositiveButton("Tutup", null)
        if (t.instruction != null || t.result != null) b.setNeutralButton("Buka file") { _, _ ->
            val u = Uri.parse(t.result ?: t.instruction!!)
            runCatching { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, contentResolver.getType(u)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                .onFailure { Toast.makeText(this, "File tidak dapat dibuka", Toast.LENGTH_SHORT).show() }
        }
        b.show()
    }

    private fun field(h: String, v: String, single: Boolean = true) = EditText(this).apply { hint = h; setText(v); textSize = 16f; isSingleLine = single }
    private fun label(s: String, size: Float, color: Int = Color.DKGRAY) = TextView(this).apply { text = s; textSize = size; setTextColor(color); setPadding(0, 6, 0, 6) }
    private fun button(s: String, action: () -> Unit) = Button(this).apply { text = s; isAllCaps = false; setOnClickListener { action() } }
    private fun keep(uri: Uri) { runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
    private fun name(uri: Uri): String = runCatching { contentResolver.query(uri, null, null, null, null)?.use { c -> val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) c.getString(i) else uri.lastPathSegment } ?: uri.lastPathSegment ?: "File" }.getOrDefault("File")
    private fun daysLeft(ms: Long): Int {
        val a = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }
        val b = Calendar.getInstance().apply { timeInMillis = ms; set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }
        return ((b.timeInMillis-a.timeInMillis)/86400000L).toInt()
    }
    private fun date(ms: Long) = SimpleDateFormat("dd MMM yyyy", Locale("id","ID")).format(Date(ms))
    private fun save() {
        val a = JSONArray()
        tasks.forEach { t -> a.put(JSONObject().apply { put("id",t.id); put("course",t.course); put("title",t.title); put("description",t.description); put("deadline",t.deadline); put("instruction",t.instruction); put("result",t.result); put("status",t.status) }) }
        prefs.edit().putString("tasks",a.toString()).apply()
    }
    private fun load() {
        tasks.clear()
        runCatching {
            val a = JSONArray(prefs.getString("tasks","[]"))
            for (i in 0 until a.length()) { val o=a.getJSONObject(i); tasks.add(Task(o.getLong("id"),o.getString("course"),o.getString("title"),o.optString("description"),o.getLong("deadline"),o.optString("instruction").takeUnless { it=="null" || it.isBlank() },o.optString("result").takeUnless { it=="null" || it.isBlank() },o.optString("status","Belum dikerjakan"))) }
        }
    }
}
